TheGhastModding's MIDI Video generator
This program can convert any midi in a mp4 file which, when played, will look like the midi is being played in BeatMIDI (BeatMIDI has been discontinued. Please stop using it. Thanks.)

How to use:
1. Use file -> Select MIDI to select a MIDI to convert
2. Press the "Convert the MIDI" button to convert the midi to mp4
3. simple as that

Video quality:
can be changed in the settings

This program uses JCodec: jcodec.org